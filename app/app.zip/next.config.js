module.exports = {
  distDir: 'build',
  trailingSlash: true,
}